import { useState, useEffect } from 'react'
import './App.scss'
import Header from './components/Header'
import Hero from './components/Hero'
import Offerings from './components/Offerings'
import Values from './components/Values'
import Features from './components/Features'
import VideoSection from './components/VideoSection'
import Footer from './components/Footer'
import ThemeToggle from './components/ThemeToggle'
import ScrollToTop from './components/ScrollToTop'

function App() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  return (
    <div className={`app ${isLoaded ? 'loaded' : ''}`}>
      <Header />
      <Hero />
      <Offerings />
      <Values />
      <Features />
      <VideoSection />
      <Footer />
      <ThemeToggle />
      <ScrollToTop />
    </div>
  )
}

export default App
