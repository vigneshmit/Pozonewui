import { useState, useEffect } from 'react'
import './Hero.scss'

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  return (
    <section className="hero">
      <div className="hero-background">
        <div className="hero-gradient"></div>
        <div className="hero-particles">
          {[...Array(20)].map((_, i) => (
            <div key={i} className={`particle particle-${i + 1}`}></div>
          ))}
        </div>
      </div>
      
      <div className="container">
        <div className="hero-content">
          <div className={`hero-text ${isVisible ? 'visible' : ''}`}>
            <div className="hero-badge">
              <span>SIMPLE • POZO • SMART • SECURE</span>
            </div>

            <h1 className="hero-title">
              <span className="title-line">Simplify your business operation</span>
              <span className="title-line highlight">with a platform powered by GenAI</span>
            </h1>

            <p className="hero-subtitle">
              <strong>Experience, Automation, Cost Efficient</strong>
            </p>

            <p className="hero-description">
              Our SaaS offering is designed to provide all of the
              tools from small & medium enterprises to large
              enterprises.
            </p>
            
            <div className="hero-actions">
              <button className="btn btn-primary btn-large">
                <span>EXPERIENCE NOW</span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <path d="M5 12h14M12 5l7 7-7 7" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </button>

              <button className="btn btn-glass btn-large">
                <span>WATCH DEMO</span>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <polygon points="5,3 19,12 5,21" fill="currentColor"/>
                </svg>
              </button>
            </div>
          </div>
          
          <div className={`hero-visual ${isVisible ? 'visible' : ''}`}>
            <div className="visual-container">
              <div className="dashboard-mockup">
                <div className="mockup-header">
                  <div className="mockup-controls">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                </div>
                <div className="mockup-content">
                  <div className="chart-area">
                    <div className="chart-bars">
                      {[...Array(8)].map((_, i) => (
                        <div key={i} className={`chart-bar bar-${i + 1}`}></div>
                      ))}
                    </div>
                  </div>
                  <div className="stats-grid">
                    <div className="stat-card">
                      <div className="stat-value">$24.5K</div>
                      <div className="stat-label">Revenue</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-value">1,247</div>
                      <div className="stat-label">Users</div>
                    </div>
                    <div className="stat-card">
                      <div className="stat-value">89%</div>
                      <div className="stat-label">Growth</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="floating-elements">
                <div className="floating-card card-1">
                  <div className="card-icon">📊</div>
                  <div className="card-text">Analytics</div>
                </div>
                <div className="floating-card card-2">
                  <div className="card-icon">🤖</div>
                  <div className="card-text">AI Powered</div>
                </div>
                <div className="floating-card card-3">
                  <div className="card-icon">⚡</div>
                  <div className="card-text">Fast</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
